lst = [1, 2, 3]
for i in iter(lst):
    print(i)
