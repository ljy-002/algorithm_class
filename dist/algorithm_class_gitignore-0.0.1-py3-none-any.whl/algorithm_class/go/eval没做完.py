class evsk():
    def sk(asks):
        ks=str(input(str(asks)))
    def ev(B):
        al=eval(str(B))

evsk.sk



