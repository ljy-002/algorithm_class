import time
import numpy


def eyezhi(zhi):

    eye = numpy.eye(zhi)

def shezhia():

    a = ['apple', 'banana', 'park', 'eat', 'ate', 1, 1, 2, 3]

def zidianjia(jiadedongxi):

    zidian = {jiadedongxi: 1}

def lenshu(di):

    azhongshu = len(di)

def append(dongxi):

    a.append(dongxi)

def chou():

    xunwen = int(input('你要抽“a”列表的的第几项？'))
    adexiangshu = a[xunwen]
    print('你要抽的第', xunwen, '项是：', adexiangshu)
    time.sleep(1)
