_5050=[]
for i in range(1,101):
    _5050.append(int(i))
print(_5050)
print("\r")
print("等于：",sum(_5050))

