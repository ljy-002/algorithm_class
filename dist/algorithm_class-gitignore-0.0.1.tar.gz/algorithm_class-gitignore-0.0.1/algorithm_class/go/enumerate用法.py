seasons=['Spring','Summer','Fall','Winter']
list(enumerate(seasons,start=1))    #下标从1开始


#简写为：
#print(list(enumerate(['Spring','Summer','Fall','Winter'],start=1)))

#还可以：
#print(list(enumerate(['Spring', 'Summer', 'Fall', 'Winter'])))

