import pyinstaller


pyinstaller options D:\PROG\LJY\李今越\杂项\文件类型\Py\整数比简化.py
