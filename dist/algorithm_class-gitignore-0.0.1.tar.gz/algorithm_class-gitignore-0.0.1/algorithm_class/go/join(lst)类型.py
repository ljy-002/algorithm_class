lst=["新","年","快","乐"]
s=''.join(lst)
print(s)

