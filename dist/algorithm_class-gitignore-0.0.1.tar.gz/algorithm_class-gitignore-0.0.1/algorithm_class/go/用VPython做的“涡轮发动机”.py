import vpython


vpython.box(length=4,height=3,width=4)
vpython.box(length=5,height=3.2,width=1,color=vpython.color.red)
vpython.box(length=1,height=3.2,width=5,color=vpython.color.red)
vpython.box(length=1,height=4,width=1,color=vpython.color.blue)
vpython.box(length=5.2,height=1,width=1,color=vpython.color.blue)
vpython.box(length=1,height=1,width=5.2,color=vpython.color.blue)
vpython.box(length=4.2,height=1,width=4.2,color=vpython.color.green)
